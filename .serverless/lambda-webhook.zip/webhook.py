import os
from flask import Flask, request, abort
import requests
import json
from twilio.request_validator import RequestValidator
from twilio.twiml.messaging_response import MessagingResponse

app = Flask(__name__)


@app.route('/', methods=['POST'])
def reset():
    incoming_msg = request.values.get('Body','').lower()
    resp = MessagingResponse()
    # print("0") 
    headers = {
        "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJVc2VySW5mbyI6eyJpZCI6MjE0MTgsInJvbGVzIjpbImRlZmF1bHQiXSwicGF0aWQiOiI1ZjE5ZmQzNS0yOGQyLTRhNjYtYmU5OC1mNjdhZGZiMmUyZTQifSwiaWF0IjoxNjg5MTAzMjY4LCJleHAiOjE2OTk0NzEyNjh9.EFDX15p4b8uxKhJcvwbMo6QUEpWvKKZw8-rOIcgmCUg",
        "Content-Type": "application/json"
        } 
    url = "https://api.psnext.info/api/chat"
    data = {
        "message": incoming_msg,
        "options": {
            "model": "gpt35turbo"
        }
    }
    # print("1")  
    if '' in incoming_msg:
        response = requests.post(url, headers=headers, data=json.dumps(data))
        data = response.json()
        content = data['data']['messages'][2]['content']
    

        resp.message(content)      
    return str(resp), 200, {'Content-Type': 'application/xml'}